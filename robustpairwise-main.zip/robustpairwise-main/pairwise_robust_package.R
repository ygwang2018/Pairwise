# ============================================================
# Pairwise Robust Regression
# Clean packaged version with:
#   - quadratic loss support
#   - pairwise non-robust baseline
#   - non-pairwise robust baseline
#   - simulation utilities
# ============================================================

# -----------------------------
# 1. Loss family
# -----------------------------
pr_loss_funs <- function(loss = c("logcosh", "cauchy", "l1", "quadratic")) {
  loss <- match.arg(loss)

  rho_fun <- switch(
    loss,
    logcosh   = function(u) log(cosh(u)),
    cauchy    = function(u) 0.5 * log(1 + u^2),
    l1        = function(u) abs(u),
    quadratic = function(u) 0.5 * u^2
  )

  psi_fun <- switch(
    loss,
    logcosh   = function(u) tanh(u),
    cauchy    = function(u) u / (1 + u^2),
    l1        = function(u) ifelse(u > 0, 1, ifelse(u < 0, -1, 0)),
    quadratic = function(u) u
  )

  # w(z) = psi(z) / z
  w_fun <- function(z) {
    out <- numeric(length(z))
    small <- abs(z) < 1e-8

    if (loss == "logcosh") {
      out[!small] <- tanh(z[!small]) / z[!small]
      out[small]  <- 1
    } else if (loss == "cauchy") {
      out[!small] <- 1 / (1 + z[!small]^2)
      out[small]  <- 1
    } else if (loss == "quadratic") {
      out[] <- 1
    } else {
      # smoothed L1
      out[!small] <- 1 / pmax(abs(z[!small]), 1e-6)
      out[small]  <- 1
    }

    out
  }

  list(loss = loss, rho = rho_fun, psi = psi_fun, w = w_fun)
}

# -----------------------------
# 2. Pair index builder
# -----------------------------
pr_make_pairs <- function(X, pair_mode = c("all", "knn"), knn_k = 10) {
  pair_mode <- match.arg(pair_mode)
  X <- as.matrix(X)
  n <- nrow(X)

  if (n < 2) stop("Need at least 2 observations.")

  if (pair_mode == "all") {
    pair_idx <- utils::combn(n, 2)
  } else {
    D <- as.matrix(stats::dist(X))
    idx_list <- vector("list", n)

    for (i in seq_len(n)) {
      ord <- order(D[i, ])
      ord <- ord[ord != i]
      nb <- ord[seq_len(min(knn_k, length(ord)))]
      idx_list[[i]] <- cbind(i, nb)
    }

    pair_mat <- do.call(rbind, idx_list)
    pair_mat <- t(apply(pair_mat, 1, sort))
    pair_mat <- unique(pair_mat)
    pair_idx <- t(pair_mat)
  }

  i_idx <- pair_idx[1, ]
  j_idx <- pair_idx[2, ]
  xdist2 <- rowSums((X[i_idx, , drop = FALSE] - X[j_idx, , drop = FALSE])^2)

  list(
    pair_idx = pair_idx,
    i_idx = i_idx,
    j_idx = j_idx,
    xdist2 = xdist2,
    m = length(i_idx)
  )
}

# -----------------------------
# 3. Small helpers
# -----------------------------
pr_safe_mad <- function(x) {
  s <- stats::mad(x, center = 0)
  if (!is.finite(s) || s <= 0) {
    s <- sqrt(mean(x^2) + 1e-8)
  }
  max(s, 1e-8)
}

pr_safe_solve <- function(A, b = NULL, ridge = 1e-8) {
  A2 <- A + diag(ridge, nrow(A))
  if (is.null(b)) solve(A2) else solve(A2, b)
}

pr_row_median_scale <- function(x, k = 11) {
  n <- length(x)
  if (n < 3) return(pmax(abs(x), 1e-6))
  k <- min(k, ifelse(n %% 2 == 1, n, n - 1))
  if (k < 3) k <- 3
  stats::runmed(x, k = k)
}

pr_colnames <- function(X) {
  X <- as.matrix(X)
  nm <- colnames(X)
  if (is.null(nm)) nm <- paste0("V", seq_len(ncol(X)))
  nm
}

# -----------------------------
# 4. Pilot fit
#    uniform weights
# -----------------------------
pilot_fit_pairwise <- function(
    X, y,
    loss = c("logcosh", "cauchy", "l1", "quadratic"),
    kappa = 1,
    pair_info = NULL,
    max_iter = 30,
    tol = 1e-6,
    verbose = FALSE
) {
  loss <- match.arg(loss)
  loss_obj <- pr_loss_funs(loss)
  rho_fun <- loss_obj$rho
  w_fun <- loss_obj$w

  X <- as.matrix(X)
  y <- as.numeric(y)
  n <- nrow(X)

  if (is.null(pair_info)) {
    pair_info <- pr_make_pairs(X, pair_mode = "all")
  }

  i_idx <- pair_info$i_idx
  j_idx <- pair_info$j_idx
  m <- pair_info$m

  beta <- as.numeric(stats::coef(stats::lm.fit(X, y)))
  beta[is.na(beta)] <- 0

  r <- y - as.vector(X %*% beta)
  sigma <- pr_safe_mad(r)

  bii <- rep(1, n)
  bij <- rep(1, m)
  s_total <- sum(bii) + sum(bij)
  bii <- bii * n / s_total
  bij <- bij * n / s_total

  objective <- function(beta, sigma) {
    r <- y - as.vector(X %*% beta)
    z <- r / sigma
    dz <- (z[i_idx] - z[j_idx]) / 2

    sum(bii * rho_fun(z)) +
      sum(bij * rho_fun(dz)) +
      kappa * log(sigma) * (sum(bii) + sum(bij))
  }

  update_sigma <- function(beta, sigma_old) {
    r <- y - as.vector(X %*% beta)
    sigma_new <- sigma_old

    for (inner in 1:100) {
      z <- r / sigma_new
      dz <- (r[i_idx] - r[j_idx]) / (2 * sigma_new)

      num_diag <- sum(bii * w_fun(z) * r^2)
      num_pair <- sum(bij * w_fun(dz) * ((r[i_idx] - r[j_idx]) / 2)^2)

      sigma_next <- sqrt((num_diag + num_pair) / (n * kappa + 1e-8))
      sigma_next <- max(sigma_next, 1e-8)

      if (abs(sigma_next - sigma_new) < tol * (1 + abs(sigma_new))) {
        sigma_new <- sigma_next
        break
      }
      sigma_new <- sigma_next
    }

    sigma_new
  }

  it <- 0
  for (it in 1:max_iter) {
    beta_old <- beta
    sigma_old <- sigma

    opt <- stats::optim(
      par = beta,
      fn = function(b) objective(b, sigma),
      method = "BFGS",
      control = list(reltol = 1e-10, maxit = 200)
    )
    beta <- opt$par
    sigma <- update_sigma(beta, sigma)

    err <- max(abs(beta - beta_old), abs(sigma - sigma_old))
    if (verbose) {
      cat(sprintf("[pilot] iter=%d err=%.3e sigma=%.6f\n", it, err, sigma))
    }
    if (err < tol) break
  }

  residuals <- y - as.vector(X %*% beta)

  list(
    coefficients = stats::setNames(beta, pr_colnames(X)),
    sigma = sigma,
    residuals = residuals,
    fitted.values = as.vector(X %*% beta),
    converged = (it < max_iter),
    iterations = it
  )
}

# -----------------------------
# 5. Estimate local scale sigma_i
# -----------------------------
estimate_local_scale <- function(
    residuals,
    method = c("global", "residual_runmed", "abs_residual"),
    global_sigma = NULL
) {
  method <- match.arg(method)
  r <- as.numeric(residuals)
  n <- length(r)

  if (is.null(global_sigma)) {
    global_sigma <- pr_safe_mad(r)
  }

  if (method == "global") {
    sigma_i <- rep(global_sigma, n)
  } else if (method == "abs_residual") {
    sigma_i <- pmax(abs(r), global_sigma)
  } else {
    s0 <- pmax(abs(r), global_sigma)
    sigma_i <- pr_row_median_scale(s0, k = min(11, ifelse(n %% 2 == 1, n, n - 1)))
  }

  sigma_i <- pmax(sigma_i, 1e-6)
  sigma_i
}

# -----------------------------
# 6. Estimate dependence
# -----------------------------
estimate_dependence <- function(
    z,
    i_idx,
    j_idx,
    dep_type = c("none", "ar1")
) {
  dep_type <- match.arg(dep_type)
  z <- as.numeric(z)
  m <- length(i_idx)

  if (dep_type == "none") {
    return(list(
      type = "none",
      dep_w = rep(1, m),
      phi = NA_real_
    ))
  }

  z1 <- z[-length(z)]
  z2 <- z[-1]
  denom <- sum(z1^2) + 1e-8
  phi_hat <- sum(z1 * z2) / denom
  phi_hat <- max(min(phi_hat, 0.95), -0.95)

  lag_ij <- abs(i_idx - j_idx)
  dep_w <- 1 - abs(phi_hat)^lag_ij
  dep_w <- pmax(dep_w, 1e-4)

  list(
    type = "ar1",
    dep_w = dep_w,
    phi = phi_hat
  )
}

# -----------------------------
# 7. Build plug-in weights
# -----------------------------
build_plugin_weights <- function(
    X,
    sigma_i,
    pair_info,
    dep_obj = NULL,
    c1 = 1,
    diag_base = 1,
    normalize_to_n = TRUE
) {
  X <- as.matrix(X)
  n <- nrow(X)

  i_idx <- pair_info$i_idx
  j_idx <- pair_info$j_idx
  xdist2 <- pair_info$xdist2

  if (is.null(dep_obj)) {
    dep_w <- rep(1, length(i_idx))
  } else {
    dep_w <- dep_obj$dep_w
  }

  lev_w <- 1 / (1 + xdist2 / c1)
  het_w <- 1 / pmax(sigma_i[i_idx] * sigma_i[j_idx], 1e-6)

  bij <- dep_w * lev_w * het_w
  bii <- rep(diag_base, n)

  if (normalize_to_n) {
    s_total <- sum(bii) + sum(bij)
    bii <- bii * n / s_total
    bij <- bij * n / s_total
  }

  list(
    bii = bii,
    bij = bij,
    i_idx = i_idx,
    j_idx = j_idx
  )
}

# -----------------------------
# 8. Objective
# -----------------------------
pairwise_objective <- function(
    beta,
    sigma_global,
    X,
    y,
    sigma_i,
    weights,
    loss = c("logcosh", "cauchy", "l1", "quadratic"),
    kappa = 1
) {
  loss <- match.arg(loss)
  loss_obj <- pr_loss_funs(loss)
  rho_fun <- loss_obj$rho

  X <- as.matrix(X)
  y <- as.numeric(y)
  beta <- as.numeric(beta)

  r <- y - as.vector(X %*% beta)
  Zi <- r / pmax(sigma_i, 1e-8)

  i_idx <- weights$i_idx
  j_idx <- weights$j_idx
  Zij <- (Zi[i_idx] - Zi[j_idx]) / 2

  diag_part <- sum(weights$bii * rho_fun(Zi))
  pair_part <- sum(weights$bij * rho_fun(Zij))
  pen_part  <- kappa * log(max(sigma_global, 1e-8)) * (sum(weights$bii) + sum(weights$bij))

  diag_part + pair_part + pen_part
}

# -----------------------------
# 9. Global sigma update
# -----------------------------
update_sigma_global <- function(
    beta,
    sigma_old,
    X,
    y,
    sigma_i,
    weights,
    loss = c("logcosh", "cauchy", "l1", "quadratic"),
    kappa = 1,
    tol = 1e-6,
    max_inner = 100
) {
  loss <- match.arg(loss)
  loss_obj <- pr_loss_funs(loss)
  w_fun <- loss_obj$w

  X <- as.matrix(X)
  y <- as.numeric(y)
  r <- y - as.vector(X %*% beta)

  i_idx <- weights$i_idx
  j_idx <- weights$j_idx

  sigma_new <- max(sigma_old, 1e-8)

  for (inner in 1:max_inner) {
    Zi <- r / pmax(sigma_i, 1e-8)
    Zij_raw <- (r[i_idx] / pmax(sigma_i[i_idx], 1e-8) -
                  r[j_idx] / pmax(sigma_i[j_idx], 1e-8)) / 2

    num_diag <- sum(weights$bii * w_fun(Zi) * r^2)
    num_pair <- sum(weights$bij * w_fun(Zij_raw) * ((r[i_idx] - r[j_idx]) / 2)^2)

    sigma_next <- sqrt((num_diag + num_pair) / (length(y) * kappa + 1e-8))
    sigma_next <- max(sigma_next, 1e-8)

    if (abs(sigma_next - sigma_new) < tol * (1 + abs(sigma_new))) {
      sigma_new <- sigma_next
      break
    }
    sigma_new <- sigma_next
  }

  sigma_new
}

# -----------------------------
# 10. Sandwich covariance (approx)
# -----------------------------
estimate_covariance_pairwise <- function(
    beta,
    sigma_global,
    X,
    y,
    sigma_i,
    weights,
    loss = c("logcosh", "cauchy", "l1", "quadratic"),
    ridge = 1e-6
) {
  loss <- match.arg(loss)
  loss_obj <- pr_loss_funs(loss)
  psi_fun <- loss_obj$psi

  X <- as.matrix(X)
  y <- as.numeric(y)
  n <- nrow(X)
  p <- ncol(X)

  r <- y - as.vector(X %*% beta)
  Zi <- r / pmax(sigma_i, 1e-8)

  i_idx <- weights$i_idx
  j_idx <- weights$j_idx

  U_diag <- matrix(0, n, p)
  for (i in 1:n) {
    U_diag[i, ] <- weights$bii[i] * X[i, ] * psi_fun(Zi[i])
  }

  U_pair <- matrix(0, n, p)
  for (k in seq_along(i_idx)) {
    i <- i_idx[k]
    j <- j_idx[k]
    z_ij <- (Zi[i] - Zi[j]) / 2
    contrib <- 0.5 * weights$bij[k] * (X[i, ] - X[j, ]) * psi_fun(z_ij)
    U_pair[i, ] <- U_pair[i, ] + contrib
    U_pair[j, ] <- U_pair[j, ] - contrib
  }

  U <- U_diag + U_pair
  meat <- stats::cov(U)

  eps <- 1e-5
  H <- matrix(0, p, p)

  f0 <- function(b) {
    pairwise_objective(
      beta = b,
      sigma_global = sigma_global,
      X = X,
      y = y,
      sigma_i = sigma_i,
      weights = weights,
      loss = loss,
      kappa = 1
    )
  }

  for (a in 1:p) {
    for (b in a:p) {
      e_a <- rep(0, p); e_a[a] <- eps
      e_b <- rep(0, p); e_b[b] <- eps

      val <- (
        f0(beta + e_a + e_b) -
          f0(beta + e_a - e_b) -
          f0(beta - e_a + e_b) +
          f0(beta - e_a - e_b)
      ) / (4 * eps^2)

      H[a, b] <- val
      H[b, a] <- val
    }
  }

  bread_inv <- pr_safe_solve(H / n, ridge = ridge)
  vcov_beta <- bread_inv %*% (meat / n) %*% bread_inv
  colnames(vcov_beta) <- rownames(vcov_beta) <- pr_colnames(X)

  list(
    vcov = vcov_beta,
    se = stats::setNames(sqrt(pmax(diag(vcov_beta), 0)), pr_colnames(X))
  )
}

# -----------------------------
# 11. Main fit
# -----------------------------
pairwise_robust_fit <- function(
    X,
    y,
    loss = c("logcosh", "cauchy", "l1", "quadratic"),
    kappa = 1,
    pair_mode = c("all", "knn"),
    knn_k = 10,
    local_scale_method = c("residual_runmed", "global", "abs_residual"),
    use_dependence = FALSE,
    dep_type = c("none", "ar1"),
    c1 = 1,
    max_iter = 50,
    tol = 1e-6,
    compute_vcov = TRUE,
    verbose = FALSE
) {
  loss <- match.arg(loss)
  pair_mode <- match.arg(pair_mode)
  local_scale_method <- match.arg(local_scale_method)
  dep_type <- match.arg(dep_type)

  X <- as.matrix(X)
  y <- as.numeric(y)

  n <- nrow(X)
  if (length(y) != n) stop("length(y) must equal nrow(X).")
  if (n < 2) stop("Need at least 2 observations.")

  pair_info <- pr_make_pairs(X, pair_mode = pair_mode, knn_k = knn_k)

  pilot <- pilot_fit_pairwise(
    X = X,
    y = y,
    loss = loss,
    kappa = kappa,
    pair_info = pair_info,
    max_iter = 30,
    tol = tol,
    verbose = verbose
  )

  beta_pilot <- as.numeric(pilot$coefficients)
  sigma_pilot <- pilot$sigma
  r_pilot <- pilot$residuals

  sigma_i <- estimate_local_scale(
    residuals = r_pilot,
    method = local_scale_method,
    global_sigma = sigma_pilot
  )

  Z_pilot <- r_pilot / sigma_i

  dep_obj <- estimate_dependence(
    z = Z_pilot,
    i_idx = pair_info$i_idx,
    j_idx = pair_info$j_idx,
    dep_type = if (use_dependence) dep_type else "none"
  )

  weights <- build_plugin_weights(
    X = X,
    sigma_i = sigma_i,
    pair_info = pair_info,
    dep_obj = dep_obj,
    c1 = c1,
    diag_base = 1,
    normalize_to_n = TRUE
  )

  beta <- beta_pilot
  sigma_global <- sigma_pilot
  obj_trace <- numeric(max_iter)

  it <- 0
  for (it in 1:max_iter) {
    beta_old <- beta
    sigma_old <- sigma_global

    opt <- stats::optim(
      par = beta,
      fn = function(b) {
        pairwise_objective(
          beta = b,
          sigma_global = sigma_global,
          X = X,
          y = y,
          sigma_i = sigma_i,
          weights = weights,
          loss = loss,
          kappa = kappa
        )
      },
      method = "BFGS",
      control = list(reltol = 1e-10, maxit = 300)
    )
    beta <- opt$par

    sigma_global <- update_sigma_global(
      beta = beta,
      sigma_old = sigma_global,
      X = X,
      y = y,
      sigma_i = sigma_i,
      weights = weights,
      loss = loss,
      kappa = kappa,
      tol = tol,
      max_inner = 100
    )

    obj_trace[it] <- pairwise_objective(
      beta = beta,
      sigma_global = sigma_global,
      X = X,
      y = y,
      sigma_i = sigma_i,
      weights = weights,
      loss = loss,
      kappa = kappa
    )

    err <- max(abs(beta - beta_old), abs(sigma_global - sigma_old))
    if (verbose) {
      cat(sprintf("[main] iter=%d err=%.3e sigma=%.6f obj=%.6f\n",
                  it, err, sigma_global, obj_trace[it]))
    }
    if (err < tol) break
  }

  converged <- (it < max_iter)

  fitted_values <- as.vector(X %*% beta)
  residuals <- y - fitted_values
  standardized_residuals <- residuals / sigma_i

  vc <- NULL
  if (compute_vcov) {
    vc <- estimate_covariance_pairwise(
      beta = beta,
      sigma_global = sigma_global,
      X = X,
      y = y,
      sigma_i = sigma_i,
      weights = weights,
      loss = loss
    )
  }

  coef_out <- stats::setNames(beta, pr_colnames(X))

  fit <- list(
    coefficients = coef_out,
    sigma = sigma_global,
    sigma_i = sigma_i,
    fitted.values = fitted_values,
    residuals = residuals,
    standardized_residuals = standardized_residuals,
    weights = weights,
    pair_info = pair_info,
    pilot = pilot,
    dependence = dep_obj,
    loss = loss,
    kappa = kappa,
    call = match.call(),
    converged = converged,
    iterations = it,
    objective = obj_trace[it],
    objective_trace = obj_trace[seq_len(it)],
    vcov = if (!is.null(vc)) vc$vcov else NULL,
    se = if (!is.null(vc)) vc$se else NULL
  )

  class(fit) <- "pairwise_robust"
  fit
}

# -----------------------------
# 12. S3 methods
# -----------------------------
print.pairwise_robust <- function(x, ...) {
  cat("Pairwise Robust Regression Fit\n")
  cat("--------------------------------\n")
  cat("Loss        :", x$loss, "\n")
  cat("Converged   :", x$converged, "\n")
  cat("Iterations  :", x$iterations, "\n")
  cat("Sigma       :", format(signif(x$sigma, 6)), "\n")
  cat("Objective   :", format(signif(x$objective, 6)), "\n\n")

  cat("Coefficients:\n")
  print(x$coefficients, ...)
  invisible(x)
}

summary.pairwise_robust <- function(object, ...) {
  beta <- object$coefficients
  se <- object$se

  if (is.null(se)) {
    coef_tab <- cbind(Estimate = beta)
  } else {
    zval <- beta / pmax(se, 1e-12)
    pval <- 2 * stats::pnorm(abs(zval), lower.tail = FALSE)
    coef_tab <- cbind(
      Estimate = beta,
      Std.Error = se,
      z.value = zval,
      p.value = pval
    )
  }

  out <- list(
    call = object$call,
    converged = object$converged,
    iterations = object$iterations,
    sigma = object$sigma,
    objective = object$objective,
    coefficients = coef_tab,
    dependence = object$dependence
  )
  class(out) <- "summary.pairwise_robust"
  out
}

print.summary.pairwise_robust <- function(x, ...) {
  cat("Summary: Pairwise Robust Regression\n")
  cat("-----------------------------------\n")
  cat("Converged  :", x$converged, "\n")
  cat("Iterations :", x$iterations, "\n")
  cat("Sigma      :", format(signif(x$sigma, 6)), "\n")
  cat("Objective  :", format(signif(x$objective, 6)), "\n")
  cat("Dependence :", x$dependence$type, "\n")
  if (!is.na(x$dependence$phi)) {
    cat("AR(1) phi  :", format(signif(x$dependence$phi, 6)), "\n")
  }
  cat("\nCoefficients:\n")
  printCoefmat(x$coefficients, P.values = TRUE, has.Pvalue = ("p.value" %in% colnames(x$coefficients)))
  invisible(x)
}

coef.pairwise_robust <- function(object, ...) object$coefficients
residuals.pairwise_robust <- function(object, ...) object$residuals
fitted.pairwise_robust <- function(object, ...) object$fitted.values
weights.pairwise_robust <- function(object, ...) object$weights

predict.pairwise_robust <- function(object, newx = NULL, ...) {
  if (is.null(newx)) return(object$fitted.values)
  newx <- as.matrix(newx)
  as.vector(newx %*% object$coefficients)
}

# -----------------------------
# 13. Non-pairwise robust fit
# -----------------------------
nonpairwise_robust_fit <- function(
    X, y,
    loss = c("cauchy", "logcosh", "l1", "quadratic"),
    max_iter = 50,
    tol = 1e-6,
    compute_vcov = TRUE,
    verbose = FALSE
) {
  loss <- match.arg(loss)

  X <- as.matrix(X)
  y <- as.numeric(y)
  n <- nrow(X)
  p <- ncol(X)

  loss_obj <- pr_loss_funs(loss)
  rho_fun <- loss_obj$rho
  w_fun <- loss_obj$w

  beta <- as.numeric(stats::coef(stats::lm.fit(X, y)))
  beta[is.na(beta)] <- 0
  sigma <- pr_safe_mad(y - as.vector(X %*% beta))

  objective <- function(b, s) {
    r <- y - as.vector(X %*% b)
    z <- r / max(s, 1e-8)
    sum(rho_fun(z)) + n * log(max(s, 1e-8))
  }

  it <- 0
  for (it in 1:max_iter) {
    beta_old <- beta
    sigma_old <- sigma

    opt <- stats::optim(
      par = beta,
      fn = function(b) objective(b, sigma),
      method = "BFGS",
      control = list(reltol = 1e-10, maxit = 300)
    )
    beta <- opt$par

    r <- y - as.vector(X %*% beta)
    z <- r / max(sigma, 1e-8)
    sigma <- sqrt(sum(w_fun(z) * r^2) / (n + 1e-8))
    sigma <- max(sigma, 1e-8)

    err <- max(abs(beta - beta_old), abs(sigma - sigma_old))
    if (verbose) {
      cat(sprintf("[nonpairwise] iter=%d err=%.3e sigma=%.6f\n", it, err, sigma))
    }
    if (err < tol) break
  }

  fitted_values <- as.vector(X %*% beta)
  residuals <- y - fitted_values
  coef_out <- stats::setNames(beta, pr_colnames(X))

  vcov_out <- NULL
  se_out <- NULL
  if (compute_vcov) {
    XtX <- crossprod(X)
    sigma2 <- mean(residuals^2)
    vcov_out <- sigma2 * pr_safe_solve(XtX)
    colnames(vcov_out) <- rownames(vcov_out) <- pr_colnames(X)
    se_out <- stats::setNames(sqrt(pmax(diag(vcov_out), 0)), pr_colnames(X))
  }

  out <- list(
    coefficients = coef_out,
    sigma = sigma,
    fitted.values = fitted_values,
    residuals = residuals,
    vcov = vcov_out,
    se = se_out,
    converged = (it < max_iter),
    iterations = it,
    loss = loss,
    call = match.call()
  )
  class(out) <- "nonpairwise_robust"
  out
}

print.nonpairwise_robust <- function(x, ...) {
  cat("Non-pairwise Robust Regression Fit\n")
  cat("----------------------------------\n")
  cat("Loss        :", x$loss, "\n")
  cat("Converged   :", x$converged, "\n")
  cat("Iterations  :", x$iterations, "\n")
  cat("Sigma       :", format(signif(x$sigma, 6)), "\n\n")
  cat("Coefficients:\n")
  print(x$coefficients, ...)
  invisible(x)
}

# -----------------------------
# 14. Simulation data generator
# -----------------------------
generate_simulation_data <- function(
    n = 100,
    p = 3,
    beta_true = c(1, 2, -1),
    sigma = 1,
    contam_frac = 0,
    contam_scale = 10,
    ar1_phi = 0,
    hetero = FALSE,
    leverage_frac = 0,
    leverage_shift = 8
) {
  if (length(beta_true) != p) stop("length(beta_true) must equal p.")

  X <- matrix(stats::rnorm(n * p), nrow = n, ncol = p)
  colnames(X) <- paste0("X", seq_len(p))

  if (leverage_frac > 0) {
    lev_idx <- sample(seq_len(n), size = floor(leverage_frac * n))
    X[lev_idx, ] <- X[lev_idx, ] + leverage_shift
  }

  base_sd <- rep(sigma, n)
  if (hetero) {
    base_sd <- sigma * (0.5 + abs(X[, 1]))
  }

  eps <- stats::rnorm(n, mean = 0, sd = base_sd)

  if (abs(ar1_phi) > 0) {
    for (i in 2:n) {
      eps[i] <- ar1_phi * eps[i - 1] + eps[i]
    }
  }

  if (contam_frac > 0) {
    idx <- sample(seq_len(n), size = floor(contam_frac * n))
    eps[idx] <- eps[idx] + stats::rnorm(length(idx), 0, contam_scale)
  }

  y <- as.vector(X %*% beta_true + eps)

  list(X = X, y = y, beta_true = beta_true, error = eps)
}

# -----------------------------
# 15. One-shot model comparison
# -----------------------------
fit_all_models <- function(
    X, y,
    pairwise_robust_loss = "cauchy",
    nonpairwise_robust_loss = "cauchy",
    pair_mode = "all",
    knn_k = 10,
    use_dependence = FALSE,
    dep_type = "ar1",
    compute_vcov = TRUE
) {
  X <- as.matrix(X)
  y <- as.numeric(y)

  fit_ols <- stats::lm.fit(X, y)
  beta_ols <- stats::setNames(as.numeric(stats::coef(fit_ols)), pr_colnames(X))
  r_ols <- y - as.vector(X %*% beta_ols)
  sigma2_ols <- sum(r_ols^2) / max(length(y) - ncol(X), 1)
  vcov_ols <- sigma2_ols * pr_safe_solve(crossprod(X))
  colnames(vcov_ols) <- rownames(vcov_ols) <- pr_colnames(X)
  se_ols <- stats::setNames(sqrt(pmax(diag(vcov_ols), 0)), pr_colnames(X))

  fit_nr <- nonpairwise_robust_fit(
    X = X,
    y = y,
    loss = nonpairwise_robust_loss,
    compute_vcov = compute_vcov
  )

  fit_pls <- pairwise_robust_fit(
    X = X,
    y = y,
    loss = "quadratic",
    pair_mode = pair_mode,
    knn_k = knn_k,
    use_dependence = use_dependence,
    dep_type = dep_type,
    compute_vcov = compute_vcov
  )

  fit_pr <- pairwise_robust_fit(
    X = X,
    y = y,
    loss = pairwise_robust_loss,
    pair_mode = pair_mode,
    knn_k = knn_k,
    use_dependence = use_dependence,
    dep_type = dep_type,
    compute_vcov = compute_vcov
  )

  list(
    ols = list(coefficients = beta_ols, se = se_ols, vcov = vcov_ols),
    robust = fit_nr,
    pairwise_ls = fit_pls,
    pairwise_robust = fit_pr
  )
}

# -----------------------------
# 16. Monte Carlo simulation
# -----------------------------
run_pairwise_simulation <- function(
    Nsim = 100,
    n = 100,
    p = 3,
    beta_true = c(1, 2, -1),
    sigma = 1,
    contam_frac = 0.1,
    contam_scale = 10,
    ar1_phi = 0,
    hetero = FALSE,
    leverage_frac = 0,
    leverage_shift = 8,
    pairwise_robust_loss = "cauchy",
    nonpairwise_robust_loss = "cauchy",
    pair_mode = "all",
    knn_k = 10,
    use_dependence = FALSE,
    dep_type = "ar1",
    compute_vcov = TRUE,
    seed = 123,
    verbose = TRUE
) {
  set.seed(seed)

  method_names <- c("ols", "robust", "pairwise_ls", "pairwise_robust")
  est_store <- setNames(vector("list", length(method_names)), method_names)
  se_store <- setNames(vector("list", length(method_names)), method_names)
  conv_store <- setNames(vector("list", length(method_names)), method_names)

  for (nm in method_names) {
    est_store[[nm]] <- matrix(NA_real_, nrow = Nsim, ncol = p)
    se_store[[nm]] <- matrix(NA_real_, nrow = Nsim, ncol = p)
    conv_store[[nm]] <- rep(TRUE, Nsim)
    colnames(est_store[[nm]]) <- beta_names <- paste0("X", seq_len(p))
    colnames(se_store[[nm]]) <- beta_names
  }

  for (sim in seq_len(Nsim)) {
    dat <- generate_simulation_data(
      n = n,
      p = p,
      beta_true = beta_true,
      sigma = sigma,
      contam_frac = contam_frac,
      contam_scale = contam_scale,
      ar1_phi = ar1_phi,
      hetero = hetero,
      leverage_frac = leverage_frac,
      leverage_shift = leverage_shift
    )

    fits <- fit_all_models(
      X = dat$X,
      y = dat$y,
      pairwise_robust_loss = pairwise_robust_loss,
      nonpairwise_robust_loss = nonpairwise_robust_loss,
      pair_mode = pair_mode,
      knn_k = knn_k,
      use_dependence = use_dependence,
      dep_type = dep_type,
      compute_vcov = compute_vcov
    )

    est_store$ols[sim, ] <- fits$ols$coefficients
    se_store$ols[sim, ] <- fits$ols$se

    est_store$robust[sim, ] <- fits$robust$coefficients
    se_store$robust[sim, ] <- if (is.null(fits$robust$se)) rep(NA_real_, p) else fits$robust$se
    conv_store$robust[sim] <- isTRUE(fits$robust$converged)

    est_store$pairwise_ls[sim, ] <- fits$pairwise_ls$coefficients
    se_store$pairwise_ls[sim, ] <- if (is.null(fits$pairwise_ls$se)) rep(NA_real_, p) else fits$pairwise_ls$se
    conv_store$pairwise_ls[sim] <- isTRUE(fits$pairwise_ls$converged)

    est_store$pairwise_robust[sim, ] <- fits$pairwise_robust$coefficients
    se_store$pairwise_robust[sim, ] <- if (is.null(fits$pairwise_robust$se)) rep(NA_real_, p) else fits$pairwise_robust$se
    conv_store$pairwise_robust[sim] <- isTRUE(fits$pairwise_robust$converged)

    if (verbose && (sim %% max(1, floor(Nsim / 10)) == 0)) {
      cat(sprintf("Simulation %d / %d completed\n", sim, Nsim))
    }
  }

  summarize_method <- function(est_mat, se_mat, conv_vec) {
    beta_mat <- matrix(beta_true, nrow = nrow(est_mat), ncol = p, byrow = TRUE)
    bias <- colMeans(est_mat, na.rm = TRUE) - beta_true
    rmse <- sqrt(colMeans((est_mat - beta_mat)^2, na.rm = TRUE))
    emp_sd <- apply(est_mat, 2, stats::sd, na.rm = TRUE)
    mean_se <- colMeans(se_mat, na.rm = TRUE)

    coverage <- rep(NA_real_, p)
    for (j in seq_len(p)) {
      ok <- is.finite(est_mat[, j]) & is.finite(se_mat[, j])
      if (any(ok)) {
        lower <- est_mat[ok, j] - 1.96 * se_mat[ok, j]
        upper <- est_mat[ok, j] + 1.96 * se_mat[ok, j]
        coverage[j] <- mean(lower <= beta_true[j] & beta_true[j] <= upper)
      }
    }

    data.frame(
      parameter = paste0("beta", seq_len(p)),
      truth = beta_true,
      bias = bias,
      rmse = rmse,
      emp_sd = emp_sd,
      mean_se = mean_se,
      coverage = coverage,
      convergence = mean(conv_vec, na.rm = TRUE),
      row.names = NULL
    )
  }

  tables <- lapply(method_names, function(nm) {
    out <- summarize_method(est_store[[nm]], se_store[[nm]], conv_store[[nm]])
    out$method <- nm
    out <- out[, c("method", "parameter", "truth", "bias", "rmse", "emp_sd", "mean_se", "coverage", "convergence")]
    out
  })

  summary_table <- do.call(rbind, tables)
  rownames(summary_table) <- NULL

  list(
    summary = summary_table,
    estimates = est_store,
    ses = se_store,
    convergence = conv_store,
    settings = list(
      Nsim = Nsim,
      n = n,
      p = p,
      beta_true = beta_true,
      sigma = sigma,
      contam_frac = contam_frac,
      contam_scale = contam_scale,
      ar1_phi = ar1_phi,
      hetero = hetero,
      leverage_frac = leverage_frac,
      leverage_shift = leverage_shift,
      pairwise_robust_loss = pairwise_robust_loss,
      nonpairwise_robust_loss = nonpairwise_robust_loss,
      pair_mode = pair_mode,
      knn_k = knn_k,
      use_dependence = use_dependence,
      dep_type = dep_type,
      compute_vcov = compute_vcov,
      seed = seed
    )
  )
}

# -----------------------------
# 17. Example
# -----------------------------
# source("pairwise_robust_package.R")
#
# dat <- generate_simulation_data(
#   n = 120,
#   p = 3,
#   beta_true = c(1, 2, -1),
#   contam_frac = 0.15,
#   contam_scale = 12,
#   ar1_phi = 0.4,
#   hetero = TRUE
# )
#
# fits <- fit_all_models(
#   X = dat$X,
#   y = dat$y,
#   pairwise_robust_loss = "cauchy",
#   nonpairwise_robust_loss = "cauchy",
#   use_dependence = TRUE
# )
#
# print(fits$pairwise_robust)
# summary(fits$pairwise_robust)
#
# sim_res <- run_pairwise_simulation(
#   Nsim = 100,
#   n = 100,
#   p = 3,
#   beta_true = c(1, 2, -1),
#   contam_frac = 0.2,
#   contam_scale = 15,
#   ar1_phi = 0.5,
#   hetero = TRUE,
#   use_dependence = TRUE,
#   verbose = TRUE
# )
#
# print(sim_res$summary)
