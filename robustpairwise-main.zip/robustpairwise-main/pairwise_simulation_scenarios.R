# ============================================================
# Simulation scenario pack for Pairwise Robust Regression
# Requires: pairwise_robust_package.R
# ============================================================

# source("pairwise_robust_package.R")

make_simulation_scenarios <- function(
    beta_true = c(1, 2, -1),
    sigma = 1
) {
  list(
    clean = list(
      name = "clean",
      description = "Clean homoskedastic independent Gaussian errors",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    heteroskedastic = list(
      name = "heteroskedastic",
      description = "Heteroskedastic Gaussian errors only",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0, hetero = TRUE,
      leverage_frac = 0, leverage_shift = 8
    ),
    ar1 = list(
      name = "ar1",
      description = "Serial dependence only",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0.5, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    contamination_light = list(
      name = "contamination_light",
      description = "Light symmetric contamination",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.10, contam_scale = 10,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    contamination_moderate = list(
      name = "contamination_moderate",
      description = "Moderate symmetric contamination",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.20, contam_scale = 15,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    contamination_heavy = list(
      name = "contamination_heavy",
      description = "Heavy symmetric contamination",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.30, contam_scale = 20,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    leverage = list(
      name = "leverage",
      description = "Leverage contamination in X only",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0.10, leverage_shift = 8
    ),
    hetero_contam = list(
      name = "hetero_contam",
      description = "Heteroskedasticity plus contamination",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.20, contam_scale = 15,
      ar1_phi = 0, hetero = TRUE,
      leverage_frac = 0, leverage_shift = 8
    ),
    ar1_contam = list(
      name = "ar1_contam",
      description = "Dependence plus contamination",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.20, contam_scale = 15,
      ar1_phi = 0.5, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    full = list(
      name = "full",
      description = "Heteroskedasticity + AR(1) + contamination + leverage",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.20, contam_scale = 15,
      ar1_phi = 0.5, hetero = TRUE,
      leverage_frac = 0.10, leverage_shift = 8
    )
  )
}

make_contamination_grid <- function(
    contam_fracs = c(0, 0.05, 0.10, 0.20, 0.30),
    beta_true = c(1, 2, -1),
    sigma = 1,
    hetero = FALSE,
    ar1_phi = 0,
    leverage_frac = 0
) {
  out <- vector("list", length(contam_fracs))
  for (k in seq_along(contam_fracs)) {
    cf <- contam_fracs[k]
    out[[k]] <- list(
      name = paste0("contam_", gsub("\\.", "p", sprintf("%.2f", cf))),
      description = paste("Contamination level", cf),
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = cf, contam_scale = ifelse(cf == 0, 10, 15),
      ar1_phi = ar1_phi, hetero = hetero,
      leverage_frac = leverage_frac, leverage_shift = 8
    )
  }
  names(out) <- vapply(out, `[[`, character(1), "name")
  out
}

make_sample_size_grid <- function(
    ns = c(50, 100, 200),
    beta_true = c(1, 2, -1),
    sigma = 1,
    contam_frac = 0.20,
    contam_scale = 15,
    hetero = TRUE,
    ar1_phi = 0.5,
    leverage_frac = 0.10
) {
  out <- vector("list", length(ns))
  for (k in seq_along(ns)) {
    nn <- ns[k]
    out[[k]] <- list(
      name = paste0("n_", nn),
      description = paste("Sample size", nn),
      n = nn, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = contam_frac, contam_scale = contam_scale,
      ar1_phi = ar1_phi, hetero = hetero,
      leverage_frac = leverage_frac, leverage_shift = 8
    )
  }
  names(out) <- vapply(out, `[[`, character(1), "name")
  out
}

run_one_scenario <- function(
    scenario,
    Nsim = 200,
    pairwise_robust_loss = "cauchy",
    nonpairwise_robust_loss = "cauchy",
    pair_mode = "all",
    knn_k = 10,
    use_dependence = FALSE,
    dep_type = "ar1",
    compute_vcov = FALSE,
    seed = 123,
    verbose = FALSE
) {
  args <- scenario
  args$Nsim <- Nsim
  args$pairwise_robust_loss <- pairwise_robust_loss
  args$nonpairwise_robust_loss <- nonpairwise_robust_loss
  args$pair_mode <- pair_mode
  args$knn_k <- knn_k
  args$use_dependence <- use_dependence
  args$dep_type <- dep_type
  args$compute_vcov <- compute_vcov
  args$seed <- seed
  args$verbose <- verbose

  desc <- args$description
  args$name <- NULL
  args$description <- NULL

  res <- do.call(run_pairwise_simulation, args)
  res$scenario_name <- scenario$name
  res$scenario_description <- desc
  res
}

run_scenario_collection <- function(
    scenarios,
    Nsim = 200,
    pairwise_robust_loss = "cauchy",
    nonpairwise_robust_loss = "cauchy",
    pair_mode = "all",
    knn_k = 10,
    use_dependence = FALSE,
    dep_type = "ar1",
    compute_vcov = FALSE,
    seed = 123,
    verbose = TRUE
) {
  if (is.null(names(scenarios))) {
    names(scenarios) <- vapply(scenarios, `[[`, character(1), "name")
  }

  results <- vector("list", length(scenarios))
  names(results) <- names(scenarios)

  for (i in seq_along(scenarios)) {
    sc <- scenarios[[i]]
    if (verbose) {
      cat(sprintf("\nRunning scenario [%d/%d]: %s\n", i, length(scenarios), sc$name))
      cat(sprintf("Description: %s\n", sc$description))
    }

    results[[i]] <- run_one_scenario(
      scenario = sc,
      Nsim = Nsim,
      pairwise_robust_loss = pairwise_robust_loss,
      nonpairwise_robust_loss = nonpairwise_robust_loss,
      pair_mode = pair_mode,
      knn_k = knn_k,
      use_dependence = use_dependence,
      dep_type = dep_type,
      compute_vcov = compute_vcov,
      seed = seed + i - 1,
      verbose = FALSE
    )
  }

  summary_table <- do.call(
    rbind,
    lapply(results, function(x) {
      out <- x$summary
      out$scenario <- x$scenario_name
      out$description <- x$scenario_description
      out[, c("scenario", "description", "method", "parameter",
              "truth", "bias", "rmse", "emp_sd", "mean_se",
              "coverage", "convergence")]
    })
  )
  rownames(summary_table) <- NULL

  list(
    scenarios = scenarios,
    results = results,
    summary = summary_table
  )
}

extract_rmse_table <- function(collection_res) {
  dat <- collection_res$summary
  keep <- dat[, c("scenario", "method", "parameter", "rmse")]
  reshape(
    keep,
    idvar = c("scenario", "parameter"),
    timevar = "method",
    direction = "wide"
  )
}

make_paper_scenario_pack <- function(beta_true = c(1, 2, -1), sigma = 1) {
  sc0 <- make_simulation_scenarios(beta_true = beta_true, sigma = sigma)
  list(
    clean = sc0$clean,
    contamination_moderate = sc0$contamination_moderate,
    heteroskedastic = sc0$heteroskedastic,
    ar1 = sc0$ar1,
    hetero_contam = sc0$hetero_contam,
    ar1_contam = sc0$ar1_contam,
    full = sc0$full
  )
}

make_ablation_scenario_pack <- function(beta_true = c(1, 2, -1), sigma = 1) {
  list(
    clean = list(
      name = "clean",
      description = "Reference clean setting",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    contam_only = list(
      name = "contam_only",
      description = "Only contamination activated",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.20, contam_scale = 15,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    hetero_only = list(
      name = "hetero_only",
      description = "Only heteroskedasticity activated",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0, hetero = TRUE,
      leverage_frac = 0, leverage_shift = 8
    ),
    dep_only = list(
      name = "dep_only",
      description = "Only AR(1) dependence activated",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0.5, hetero = FALSE,
      leverage_frac = 0, leverage_shift = 8
    ),
    leverage_only = list(
      name = "leverage_only",
      description = "Only leverage contamination activated",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0, contam_scale = 10,
      ar1_phi = 0, hetero = FALSE,
      leverage_frac = 0.10, leverage_shift = 8
    ),
    full = list(
      name = "full",
      description = "All mechanisms activated",
      n = 100, p = length(beta_true), beta_true = beta_true, sigma = sigma,
      contam_frac = 0.20, contam_scale = 15,
      ar1_phi = 0.5, hetero = TRUE,
      leverage_frac = 0.10, leverage_shift = 8
    )
  )
}

# Example:
# source("pairwise_robust_package.R")
# source("pairwise_simulation_scenarios.R")
# pack <- make_paper_scenario_pack()
# res <- run_scenario_collection(
#   scenarios = pack,
#   Nsim = 200,
#   use_dependence = TRUE,
#   compute_vcov = FALSE,
#   verbose = TRUE
# )
# print(res$summary)
