library(MASS)
data(Boston)

set.seed(1234)

n <- nrow(Boston)
Boston_contam <- Boston

# random isolated contamination
contam_frac_y <- 0.15
contam_frac_x <- 0.15

contam_idx_y <- sample(seq_len(n), size = floor(contam_frac_y * n))
contam_idx_x <- sample(setdiff(seq_len(n), contam_idx_y),
                       size = floor(contam_frac_x * n))

# y isolated vertical outliers
Boston_contam$medv[contam_idx_y] <-
  Boston$medv[contam_idx_y] +
  rnorm(length(contam_idx_y), mean = 0, sd = 18)

Boston_contam$medv <- pmax(Boston_contam$medv, 1)

# x isolated leverage outliers, mild-to-moderate
Boston_contam$rm[contam_idx_x] <-
  Boston$rm[contam_idx_x] +
  sample(c(-1.0, 1.0), length(contam_idx_x), replace = TRUE)

Boston_contam$rm <- pmax(Boston_contam$rm, 1)

overlap_idx <- intersect(contam_idx_x, contam_idx_y)
clean_idx <- setdiff(seq_len(n), union(contam_idx_x, contam_idx_y))

par(mfrow = c(1, 2))

plot(Boston$rm, Boston$medv,
     main = "Original",
     xlab = "RM", ylab = "MEDV",
     pch = 19, col = "grey70")

plot(Boston_contam$rm, Boston_contam$medv,
     main = "Isolated Contamination",
     xlab = "RM", ylab = "MEDV",
     pch = 19, col = "grey70")

points(Boston_contam$rm[contam_idx_y],
       Boston_contam$medv[contam_idx_y],
       col = "blue", pch = 19)

points(Boston_contam$rm[contam_idx_x],
       Boston_contam$medv[contam_idx_x],
       col = "red", pch = 19)

legend("topleft",
       legend = c("Clean", "Y-outlier", "X-leverage"),
       col = c("grey70", "blue", "red"),
       pch = 19)
# ==============================
# 3. Load your package
# ==============================
source("C:/Users/uqjwu15/Desktop/pairwise_robust_package.R")

# ==============================
# 4. Storage
# ==============================
pred_ols <- rep(NA, n)
pred_robust_logcosh <- rep(NA, n)
pred_robust_cauchy <- rep(NA, n)
pred_pwls <- rep(NA, n)
pred_pwlogcosh <- rep(NA, n)
pred_pwcauchy <- rep(NA, n)

# ==============================
# ==============================
# 5. Leave-one-out prediction
# ==============================
for (t in 1:n) {

  cat("Running t =", t, "\n")
  
  # ------------------------------
  # train: contaminated data excluding t
  # test : clean original data at t
  # ------------------------------
  X_raw <- as.matrix(Boston_contam[-t, 1:13])
  y_train <- Boston_contam[-t, 14]
  
  # scaling from training data only
  mu  <- colMeans(X_raw)
  sdx <- apply(X_raw, 2, sd)
  sdx[sdx == 0] <- 1
  
  X_train_scaled <- scale(X_raw, center = mu, scale = sdx)
  X_train <- cbind(Intercept = 1, X_train_scaled)
  
  X_test_scaled <- scale(
    as.matrix(Boston[t, 1:13, drop = FALSE]),
    center = mu,
    scale = sdx
  )
  X_test <- cbind(Intercept = 1, X_test_scaled)
  
  # ------------------------------
  # 5.1 OLS
  # ------------------------------
  fit_ols <- lm.fit(X_train, y_train)
  beta_ols <- coef(fit_ols)
  beta_ols[is.na(beta_ols)] <- 0
  
  pred_ols[t] <- as.numeric(X_test %*% beta_ols)
  
  # ------------------------------
  # 5.2 Non-pairwise Robust logcosh
  # ------------------------------
  fit_robust_logcosh <- nonpairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "logcosh",
    max_iter = 10,
    tol = 1e-4,
    compute_vcov = FALSE,
    verbose = FALSE
  )
  
  pred_robust_logcosh[t] <- as.numeric(
    X_test %*% fit_robust_logcosh$coefficients
  )
  
  # ------------------------------
  # 5.3 Non-pairwise Robust cauchy
  # ------------------------------
  fit_robust_cauchy <- nonpairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "cauchy",
    max_iter = 10,
    tol = 1e-4,
    compute_vcov = FALSE,
    verbose = FALSE
  )
  
  pred_robust_cauchy[t] <- as.numeric(
    X_test %*% fit_robust_cauchy$coefficients
  )
  
  # ------------------------------
  # 5.4 Pairwise LS / quadratic
  # ------------------------------
  fit_pwls <- pairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "quadratic",
    pair_mode = "knn",
    knn_k = 200,
    local_scale_method ="residual_runmed",
    c1 = 500,
    max_iter = 10,
    tol = 1e-4,
    compute_vcov = FALSE,
    verbose = FALSE
  )
  
  pred_pwls[t] <- as.numeric(
    X_test %*% fit_pwls$coefficients
  )
  
  # ------------------------------
  # 5.5 Pairwise Robust logcosh
  # ------------------------------
  fit_pwlogcosh <- pairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "logcosh",
    pair_mode = "knn",
    knn_k = 200,
    local_scale_method = "residual_runmed",
    c1 = 500,
    max_iter = 10,
    tol = 1e-4,
    compute_vcov = FALSE,
    verbose = FALSE
  )
  
  pred_pwlogcosh[t] <- as.numeric(
    X_test %*% fit_pwlogcosh$coefficients
  )
  
  # ------------------------------
  # 5.6 Pairwise Robust cauchy
  # ------------------------------
  fit_pwcauchy <- pairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "cauchy",
    pair_mode = "knn",
    knn_k = 200,
    local_scale_method = "residual_runmed",
    c1 = 500,
    max_iter = 10,
    tol = 1e-4,
    compute_vcov = FALSE,
    verbose = FALSE
  )
  
  pred_pwcauchy[t] <- as.numeric(
    X_test %*% fit_pwcauchy$coefficients
  )
}
# ==============================
# 6. Metrics
# ==============================
rmse <- function(y, yhat) {
  sqrt(mean((y - yhat)^2, na.rm = TRUE))
}

mae <- function(y, yhat) {
  mean(abs(y - yhat), na.rm = TRUE)
}

mre <- function(y, yhat) {
  mean(abs((y - yhat) / pmax(abs(y), 1e-6)), na.rm = TRUE)
}

medae <- function(y, yhat) {
  median(abs(y - yhat), na.rm = TRUE)
}

r2 <- function(y, yhat) {
  1 - sum((y - yhat)^2) / sum((y - mean(y))^2)
}

y_true <- Boston[, 14]
y_true[6]
# ==============================
# 7. Result table
# ==============================
res <- data.frame(
  Model = c(
    "OLS",
    "Robust-logcosh",
    "Robust-cauchy",
    "PWLS-quadratic",
    "PW-logcosh",
    "PW-cauchy"
  ),
  
  RMSE = c(
    rmse(y_true, pred_ols),
    rmse(y_true, pred_robust_logcosh),
    rmse(y_true, pred_robust_cauchy),
    rmse(y_true, pred_pwls),
    rmse(y_true, pred_pwlogcosh),
    rmse(y_true, pred_pwcauchy)
  ),
  
  MAE = c(
    mae(y_true, pred_ols),
    mae(y_true, pred_robust_logcosh),
    mae(y_true, pred_robust_cauchy),
    mae(y_true, pred_pwls),
    mae(y_true, pred_pwlogcosh),
    mae(y_true, pred_pwcauchy)
  ),
  
  MedAE = c(
    medae(y_true, pred_ols),
    medae(y_true, pred_robust_logcosh),
    medae(y_true, pred_robust_cauchy),
    medae(y_true, pred_pwls),
    medae(y_true, pred_pwlogcosh),
    medae(y_true, pred_pwcauchy)
  ),
  
  MRE = c(
    mre(y_true, pred_ols),
    mre(y_true, pred_robust_logcosh),
    mre(y_true, pred_robust_cauchy),
    mre(y_true, pred_pwls),
    mre(y_true, pred_pwlogcosh),
    mre(y_true, pred_pwcauchy)
  ),
  
  R2 = c(
    r2(y_true, pred_ols),
    r2(y_true, pred_robust_logcosh),
    r2(y_true, pred_robust_cauchy),
    r2(y_true, pred_pwls),
    r2(y_true, pred_pwlogcosh),
    r2(y_true, pred_pwcauchy)
  )
)

print(res)

plot(y_true, pred_ols)
plot(y_true, pred_pwlogcosh)
# ==============================
# 8. Optional: save results
# ==============================
write.csv(res, "boston_prediction_results.csv", row.names = FALSE)