source("C:/Users/uqjwu15/Desktop/pairwise_robust_package.R")

# =====================================
# Load built-in dataset
data(lynx)

start(lynx)
end(lynx)
frequency(lynx)

plot(log10(lynx),
     main = "Log10 Canadian Lynx Series",
     ylab = "log10(lynx)",
     xlab = "Year")

# log-transform
y_raw <- as.numeric(log(lynx))
year_raw <- as.numeric(time(lynx))

# =====================================
# AR(2) regression setup:
# y_t = beta0 + beta1 y_{t-1} + beta2 y_{t-2} + error_t

n <- length(y_raw)

y_all <- y_raw[3:n]

X_df <- data.frame(
  x1 = y_raw[2:(n - 1)],   # y_{t-1}
  x2 = y_raw[1:(n - 2)]    # y_{t-2}
)

# design matrix with intercept
X_all <- model.matrix(~ x1 + x2, data = X_df)

# optional: aligned years
year_all <- year_raw[3:n]

head(data.frame(year = year_all, y = y_all, X_df))
# =====================================
# 2. Rolling forecasting settings
# =====================================
n <- nrow(X_all)
initial_window <- 80   # choose a reasonable initial training size
h <- 1                 # one-step-ahead forecasting

# forecast storage
pred_ols    <- rep(NA_real_, n)
pred_robust <- rep(NA_real_, n)
pred_pwls   <- rep(NA_real_, n)
pred_pwrob  <- rep(NA_real_, n)

# optional: store phi estimates for pairwise methods
phi_pwls  <- rep(NA_real_, n)
phi_pwrob <- rep(NA_real_, n)

# =====================================
# 3. Rolling expanding-window forecast
# =====================================
for (t in initial_window:(n - h)) {
  
  # training sample: 1,...,t
  X_train <- X_all[1:t, , drop = FALSE]
  y_train <- y_all[1:t]
  
  # test sample: t+1
  X_test <- X_all[t + h, , drop = FALSE]
  y_test <- y_all[t + h]
  
  # -------------------------
  # 3.1 OLS
  # -------------------------
  fit_ols <- lm.fit(X_train, y_train)
  beta_ols <- coef(fit_ols)
  beta_ols[is.na(beta_ols)] <- 0
  pred_ols[t + h] <- as.numeric(X_test %*% beta_ols)
  
  # -------------------------
  # 3.2 Robust (cauchy)
  # -------------------------
  fit_robust <- nonpairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "logcosh"
  )
  pred_robust[t + h] <- as.numeric(X_test %*% fit_robust$coefficients)
  
  # -------------------------
  # -------------------------
  # 3.3 Pairwise LS (quadratic) with AR(1)-adjusted forecast
  # -------------------------
  fit_pwls <- pairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "quadratic",
    use_dependence = TRUE,
    dep_type = "ar1",
    compute_vcov = FALSE
  )
  
  beta_pwls <- fit_pwls$coefficients
  phi_hat_pwls <- fit_pwls$dependence$phi
  
  base_pred_pwls <- as.numeric(X_test %*% beta_pwls)
  last_res_pwls <- y_train[length(y_train)] -
    as.numeric(X_train[nrow(X_train), , drop = FALSE] %*% beta_pwls)
  
  pred_pwls[t + h] <- base_pred_pwls + phi_hat_pwls * last_res_pwls
  phi_pwls[t + h] <- phi_hat_pwls
  
  
  # -------------------------
  # 3.4 Pairwise Robust (cauchy) with AR(1)-adjusted forecast
  # -------------------------
  fit_pwrob <- pairwise_robust_fit(
    X = X_train,
    y = y_train,
    loss = "logcosh",
    use_dependence = TRUE,
    dep_type = "ar1",
    compute_vcov = FALSE
  )
  
  beta_pwrob <- fit_pwrob$coefficients
  phi_hat_pwrob <- fit_pwrob$dependence$phi
  
  base_pred_pwrob <- as.numeric(X_test %*% beta_pwrob)
  last_res_pwrob <- y_train[length(y_train)] -
    as.numeric(X_train[nrow(X_train), , drop = FALSE] %*% beta_pwrob)
  
  pred_pwrob[t + h] <- base_pred_pwrob + phi_hat_pwrob * last_res_pwrob
  phi_pwrob[t + h] <- phi_hat_pwrob
  
  if (t %% 20 == 0) {
    cat("Rolling step:", t, "of", n - h, "\n")
  }
}

# =====================================
# 4. Forecast evaluation
# =====================================
eval_idx <- (initial_window + h):n
y_true <- y_all[eval_idx]

rmse <- function(y, yhat) sqrt(mean((y - yhat)^2, na.rm = TRUE))
mae  <- function(y, yhat) mean(abs(y - yhat), na.rm = TRUE)
mape <- function(y, yhat) mean(abs((y - yhat)/y), na.rm = TRUE)
smape <- function(y, yhat) {
  mean(2 * abs(y - yhat) / (abs(y) + abs(yhat)), na.rm = TRUE)
}
mase <- function(y, yhat) {
  scale <- mean(abs(diff(y)), na.rm = TRUE)
  mean(abs(y - yhat), na.rm = TRUE) / scale
}
r2 <- function(y, yhat) {
  1 - sum((y - yhat)^2) / sum((y - mean(y))^2)
}
medae <- function(y, yhat) median(abs(y - yhat), na.rm = TRUE)
quantile_loss <- function(y, yhat, tau = 0.9) {
  e <- y - yhat
  mean(pmax(tau * e, (tau - 1) * e), na.rm = TRUE)
}
directional_acc <- function(y, yhat) {
  mean(sign(diff(y)) == sign(diff(yhat)), na.rm = TRUE)
}
theil_u <- function(y, yhat) {
  num <- sqrt(mean((y - yhat)^2))
  den <- sqrt(mean(diff(y)^2))
  num / den
}

results_forecast <- data.frame(
  Method = c("OLS", "Robust_logcosh", "Pairwise_LS", "Pairwise_Robust"),
  
  RMSE = c(
    rmse(y_true, pred_ols[eval_idx]),
    rmse(y_true, pred_robust[eval_idx]),
    rmse(y_true, pred_pwls[eval_idx]),
    rmse(y_true, pred_pwrob[eval_idx])
  ),
  
  MAE = c(
    mae(y_true, pred_ols[eval_idx]),
    mae(y_true, pred_robust[eval_idx]),
    mae(y_true, pred_pwls[eval_idx]),
    mae(y_true, pred_pwrob[eval_idx])
  ),
  
  sMAPE = c(
    smape(y_true, pred_ols[eval_idx]),
    smape(y_true, pred_robust[eval_idx]),
    smape(y_true, pred_pwls[eval_idx]),
    smape(y_true, pred_pwrob[eval_idx])
  ),
  
  MASE = c(
    mase(y_true, pred_ols[eval_idx]),
    mase(y_true, pred_robust[eval_idx]),
    mase(y_true, pred_pwls[eval_idx]),
    mase(y_true, pred_pwrob[eval_idx])
  ),
  
  MedAE = c(
    medae(y_true, pred_ols[eval_idx]),
    medae(y_true, pred_robust[eval_idx]),
    medae(y_true, pred_pwls[eval_idx]),
    medae(y_true, pred_pwrob[eval_idx])
  ),
  
  Directional_Acc = c(
    directional_acc(y_true, pred_ols[eval_idx]),
    directional_acc(y_true, pred_robust[eval_idx]),
    directional_acc(y_true, pred_pwls[eval_idx]),
    directional_acc(y_true, pred_pwrob[eval_idx])
  )
)

print(results_forecast)



# =====================================
# 5. Forecast plot
# =====================================
err_ols    <- y_all - pred_ols
err_robust <- y_all - pred_robust
err_pwls   <- y_all - pred_pwls
err_pwrob  <- y_all - pred_pwrob
# =====================================
# Figure 1: QQ plot comparison
# =====================================
library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)
year_eval <- year_all[eval_idx]
# =====================================
# Figure 1: QQ plot comparison
# =====================================

qq_data <- data.frame(
  residual = err_pwls
)

p_qq <- ggplot(qq_data, aes(sample = residual)) +
  stat_qq(size = 2.2, alpha = 0.75, color = "#FDAE61") +
  stat_qq_line(linewidth = 1.1, color =  "black") +
  labs(
    title = "(a) Q-Q Plot",
    x = "Theoretical Quantiles",
    y = "Sample Quantiles"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 17),
    plot.subtitle = element_text(size = 12, color = "gray35"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "gray88"),
    axis.title = element_text(face = "bold")
  )

print(p_qq)


# =====================================
# Figure 2: Rolling one-step-ahead forecast
# =====================================

forecast_df <- data.frame(
  Time = eval_idx,
  Year = year_eval, 
  Actual = y_true,
  OLS = pred_ols[eval_idx],
  Robust_LogCosh = pred_robust[eval_idx],
  Pairwise_LS = pred_pwls[eval_idx],
  Pairwise_Robust = pred_pwrob[eval_idx]
) %>%
  pivot_longer(
    cols = -c(Time, Year),
    names_to = "Model",
    values_to = "Value"
  )

forecast_df$Model <- factor(
  forecast_df$Model,
  levels = c(
    "Actual",
    "OLS",
    "Robust_LogCosh",
    "Pairwise_LS",
    "Pairwise_Robust"
  ),
  labels = c(
    "Actual",
    "OLS",
    "Robust lncosh",
    "Pairwise LS",
    "Pairwise Robust lncosh"
  )
)

p_forecast <- ggplot(forecast_df, aes(x = Year, y = Value)) +
  geom_line(
    aes(color = Model, linewidth = Model, linetype = Model),
    alpha = 0.95
  ) +
  scale_color_manual(
    values = c(
      "Actual" = "black",
      "OLS" = "#D7191C",
      "Robust lncosh" = "#1A9641",
      "Pairwise LS" = "#FDAE61",
      "Pairwise Robust lncosh" = "#2C7BB6"
    )
  ) +
  scale_linewidth_manual(
    values = c(
      "Actual" = 1.25,
      "OLS" = 0.85,
      "Robust lncosh" = 0.85,
      "Pairwise LS" = 0.85,
      "Pairwise Robust lncosh" = 1.05
    )
  ) +
  scale_linetype_manual(
    values = c(
      "Actual" = "solid",
      "OLS" = "dashed",
      "Robust lncosh" = "dotdash",
      "Pairwise LS" = "twodash",
      "Pairwise Robust lncosh" = "solid"
    )
  ) +
  scale_x_continuous(
    breaks = pretty(year_eval, n = 6)
  ) +
  labs(
    title = "(b) Rolling One-Step-Ahead Forecast",
    x = "Year",
    y = "Log Response",
    color = NULL,
    linewidth = NULL,
    linetype = NULL
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 17),
    plot.subtitle = element_text(size = 12, color = "gray35"),
    axis.title = element_text(face = "bold"),
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.text = element_text(size = 11),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "gray88")
  )

p_qq + p_forecast +
  plot_layout(ncol = 2, widths = c(1, 2))


